package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int Confirmacion;
        do {

            Scanner leer = new Scanner(System.in);



                // REGISTRO DEL DOCTOR //

                System.out.println("Cual es el nombre del doctor?");
                String DoctorNombre = leer.nextLine();

                System.out.println("Cual es el apellido del doctor?");
                String DoctorApellido = leer.nextLine();

                System.out.println("Cual es la especialidad del doctor?");
                System.out.println("Escriba el numero correspondiente.");
                System.out.println("1. Cirugia general. 2. Medicina Interna.");
                System.out.println("3. Obstetricia. 4. Traumatología.");
                System.out.println("5. Ginecología. 6. Neonatología.");
                System.out.println("7. Cirugía plástica y estética..");
                int DoctorEspecialidad = leer.nextInt();

                System.out.println("Se a registrado satisfactoriamente al doctor.");
                String checkpoint = leer.nextLine();
                System.out.println("-----------------------------------------------");


                // REGISTRO DEL PACIENTE //

                System.out.println("Cual es el nombre del paciente?");
                String PacienteNombre = leer.nextLine();

                System.out.println("Cual es el apellido del paciente?");
                String PacienteApellido = leer.nextLine();

                System.out.println("Cual es la especialidad que busca el paciente?");
                System.out.println("Escriba el numero correspondiente.");
                System.out.println("1. Cirugia general. 2. Medicina Interna.");
                System.out.println("3. Obstetricia. 4. Traumatología.");
                System.out.println("5. Ginecología. 6. Neonatología.");
                System.out.println("7. Cirugía plástica y estética..");
                int PacienteEspecialidad = leer.nextInt();


                System.out.println("Se a registrado satisfactoriamente al paciente.");
                String checkpoint1 = leer.nextLine();
                System.out.println("-----------------------------------------------");

                if (DoctorEspecialidad == PacienteEspecialidad) {

                    System.out.println("Actualmente si hay doctores para atenderlo.");

                } else {

                    System.out.println("Actualmente no hay doctores para atenderlo.");
                    System.exit(1);

                }


            // REGISTRO FECHA ///

            System.out.println("En que fecha requiere la cita?");
            String CiteFecha = leer.nextLine();

            System.out.println("En que mes requiere la cita?");
            String CitaMes = leer.nextLine();






            // CONFIRMACION //

            System.out.print("La cita del paciente " + PacienteNombre);
            System.out.println(" " + PacienteApellido);
            System.out.print(" se a programado para la fecha " + CiteFecha);
            System.out.println(" del mes " + CitaMes);
            System.out.print(" El doctor que lo atendera sera " + DoctorNombre);
            System.out.println(" " + DoctorApellido);
            System.out.println("Esta usted de acuerdo con la cita?");
            System.out.println("1 para SI.");
            System.out.println("2 para NO.");
                 Confirmacion = leer.nextInt();


            if (Confirmacion == 2) {

                System.out.println("Se volvera a reagendar la cita.");
                System.out.println("-----------------------------------------------");

            }
            else {}

        }
        while (Confirmacion <= 2);

    }

        }
